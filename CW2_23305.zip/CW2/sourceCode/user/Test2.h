#ifndef __Test2_H
#define __Test2_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "libc.h"

#endif
