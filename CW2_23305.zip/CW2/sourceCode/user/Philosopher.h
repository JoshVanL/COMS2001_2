
#ifndef __Philosopher_H
#define __Philosopher_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>




#include "libc.h"


#endif
