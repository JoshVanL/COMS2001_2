#ifndef __P3_H
#define __P3_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "libc.h"

#endif
