#ifndef __Factory_H
#define __Factory_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "libc.h"

#endif
