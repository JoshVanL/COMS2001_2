#ifndef __DECODER_H
#define __DECODER_H

#include "hilevel.h"

extern char decode(int x);


#endif
